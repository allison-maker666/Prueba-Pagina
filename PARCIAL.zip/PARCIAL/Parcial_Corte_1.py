# Allison Farias - Juan Pinzon 12/03/26

from collections import deque
 
cola = deque()
historial = []
contador = 1


def registrar_pedido():
    global contador
    print("\n📝 NUEVO PEDIDO")
    cliente  = input("  Ingresa tu nombre:  ")
    print(f"¿Que deseas ordenar hoy {cliente}?")
    producto = input("  Ingresa el producto a pedir:  ")
 
    pedido = {
        "id": f"#{contador:03d}",
        "cliente": cliente,
        "producto": producto,
        "estado": "En espera"
    }
    contador += 1
    cola.append(pedido) # enqueue
    print(f"\n  ✅ Pedido {pedido['id']} de {cliente} agregado con exito :D")
    print(f"  📊 Pedidos en espera: {len(cola)}")
 

def despachar_pedido():
    print("\n🛵 DESPACHAR PEDIDO")
    if not cola:
        print("  ℹ️  No hay pedidos en la cola.")
        return
 
    pedido = cola.popleft() # dequeue
    pedido["estado"] = "Entregado"
    historial.append(pedido)
 
    print(f"\n  ✅ Despachando pedido {pedido['id']}...")
    print(f"  👤 Cliente:  {pedido['cliente']}")
    print(f"  🛍️  Producto: {pedido['producto']}")
    print(f"  📊 Pedidos restantes en espera: {len(cola)}")
 
 
def ver_cola():
    print("\n⏳ COLA DE PEDIDOS EN ESPERA")
    if not cola:
        print("  ℹ️  La cola está vacía.")
        return
    for i, p in enumerate(cola, 1):
        print(f"  {i}. {p['id']} | {p['cliente']} | {p['producto']}")
 
 
def ver_historial():
    print("\n📋 PEDIDOS ENTREGADOS")
    if not historial:
        print("  ℹ️  Aún no se ha entregado ningún pedido.")
        return
    for p in historial:
        print(f"  ✅ {p['id']} | {p['cliente']} | {p['producto']}")
 
 
def menu():
    while True:
        print("\n" + "═" * 60)
        print("   🛵  BIENVENIDO A NUESTRA PLATAFORMA DE DOMICILIOS")
        print("             ¿Que accion deseas realizar?")
        print("═" * 60)
        print("  1. Registrar pedido")
        print("  2. Despachar siguiente pedido")
        print("  3. Ver cola de espera")
        print("  4. Ver pedidos entregados")
        print("  5. Salir")
        print("─" * 60)
 
        opcion = input("  Opción: ").strip()
 
        if opcion == "1":
            registrar_pedido()
        elif opcion == "2":
            despachar_pedido()
        elif opcion == "3":
            ver_cola()
        elif opcion == "4":
            ver_historial()
        elif opcion == "5":
            print("\n  👋 ¡Hasta luego!\n")
            break
        else:
            print("\n  ⚠️  Opción inválida, digita una opción que este dentro del menu")


if __name__ == "__main__":
    menu()